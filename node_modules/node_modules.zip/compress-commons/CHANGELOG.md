## Changelog

**2.1.1** — <small>_August 2, 2019_</small> — [Diff](https://github.com/archiverjs/node-compress-commons/compare/2.1.0...2.1.1)

- update crc32-stream to v3.0.1

**2.1.0** — <small>_August 2, 2019_</small> — [Diff](https://github.com/archiverjs/node-compress-commons/compare/2.0.0...2.1.0)

- update crc32-stream to v3.0.0

**2.0.0** — <small>_July 19, 2019_</small> — [Diff](https://github.com/archiverjs/node-compress-commons/compare/1.2.2...2.0.0)

- breaking: follow node LTS, remove support for versions under 6.
- test: now targeting node v10 and v12
- fix: update Buffer calls to alloc/from
- fix: Add offset to buffer call (#31)
- other: update normalize-path@3 (#34)
- other: update dependencies

[Release Archive](https://github.com/archiverjs/node-compress-commons/releases)
