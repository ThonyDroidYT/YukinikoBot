## Changelog

**2.1.0** — <small> July 19, 2019 </small> — [Diff](https://github.com/archiverjs/archiver-utils/compare/2.0.0...2.1.0)

- other: less lodash (#16)
- other: update dependencies

**2.0.0** — <small> August 22, 2018 </small> — [Diff](https://github.com/archiverjs/archiver-utils/compare/1.3.0...2.0.0)

- breaking: follow node LTS, remove support for versions under 6.
- other: remove unused lodash dependence (#13)
- test: now targeting node v10

[Release Archive](https://github.com/archiverjs/archiver-utils/releases)